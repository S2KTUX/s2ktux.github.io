-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: opentracing-cpp
Binary: libopentracing-dev, libopentracing1
Architecture: any
Version: 1.6.0-4
Maintainer: Stephen Gelman <ssgelm@debian.org>
Homepage: https://github.com/opentracing/opentracing-cpp/
Standards-Version: 4.6.1.0
Vcs-Browser: https://salsa.debian.org/ssgelm/opentracing-cpp
Vcs-Git: https://salsa.debian.org/ssgelm/opentracing-cpp.git
Build-Depends: debhelper-compat (= 13), cmake
Package-List:
 libopentracing-dev deb libdevel optional arch=any
 libopentracing1 deb libs optional arch=any
Checksums-Sha1:
 aa9b4e1c89524f58643da42c6adfc5865056b93d 124968 opentracing-cpp_1.6.0.orig.tar.xz
 7d30fd68525e1272f7c4a03cef12314c34ee1859 4684 opentracing-cpp_1.6.0-4.debian.tar.xz
Checksums-Sha256:
 cd3c3d311069f6bf4c0a6853776eb641e73e0cea01ec04e494056ae2b3139633 124968 opentracing-cpp_1.6.0.orig.tar.xz
 793721cd2798c0a431a2d8b3c888c4f93f826bded0e28fc8f3ff70a97e8895dd 4684 opentracing-cpp_1.6.0-4.debian.tar.xz
Files:
 8ded419b8ad9de683a7123ec4202b8fb 124968 opentracing-cpp_1.6.0.orig.tar.xz
 3da58d8b6a70a0f5cd007d15dcf406ee 4684 opentracing-cpp_1.6.0-4.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQJGBAEBCgAwFiEEPwDop1BN06KlsbfijqM4hED8f1wFAmNGBEsSHHNzZ2VsbUBk
ZWJpYW4ub3JnAAoJEI6jOIRA/H9cBHUP/R0jOPc9z5M3GouPnSR7uzZ8EngCfsAw
nLPEATNjIsPrU9MnGuo0IlW9/CRbDv/Kk3Gpk1m96GiFBk9FOlg2nsUR8W8XOUQu
WN0dvzo/8YuwHVpXc+bzey5D2jISTHUCbAl09M+ndKUAZhh6k9bkcdkvpmNN7jiN
0mSXH/WO6uLVS4a6O/ml/iksTcYbZ0h7fX2wlSYkc/FGfIFhQPnAlNlFrBSOYM7M
0Qz2fxMId3k6FMI2ilVy/rIntfhwvu9SuDmndO6mr4mEOoWb3DMQGVWAekBpYkrM
ixoTQGs5Zhu33Dr9ZIK1wNqV0SVMMoxkuV+Pbqvu+t/cHnLhMaaG6jazBOa9PWk3
NTUtGcnL1LrHqUGVa4nwPTKKjhjIhXTHacoJJhTRyXD/bkVs2a7gVRgbqEXARDuc
YEQaiz3+mjbHXp5C+nPKSEgBne8SNYctxVmSaAt3Oub7BTkTkyDmzfDJmnfJThKK
uAmUNeLdCbZCBPFqMLRn4LytBlcGmbkOPjliUT0zEOW4tFgAkYC5kQXUgmVxLdyU
chbNeheupBZrWnShTL0rG2YbFWPD1W0pgrEoJbWmusOr+cZFMgaWYrkaZN/8cvDp
R8ficMbiqG/np9XEoRuHTg9762PKtLfkLqxJK0Dsr2kGNxtrBJ1lm1YiXF0+ChzF
omynHEKer7Wl
=HzoM
-----END PGP SIGNATURE-----
