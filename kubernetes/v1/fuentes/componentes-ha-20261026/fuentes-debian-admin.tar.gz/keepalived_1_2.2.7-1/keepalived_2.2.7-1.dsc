-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA256

Format: 3.0 (quilt)
Source: keepalived
Binary: keepalived
Architecture: any
Version: 1:2.2.7-1
Maintainer: Vincent Bernat <bernat@debian.org>
Homepage: http://keepalived.org
Standards-Version: 4.6.0.1
Vcs-Browser: https://salsa.debian.org/debian/pkg-keepalived
Vcs-Git: https://salsa.debian.org/debian/pkg-keepalived.git
Build-Depends: autoconf, debhelper-compat (= 13), libglib2.0-dev, libip4tc-dev, libipset-dev, libjson-c-dev, libnfnetlink-dev, libnftnl-dev, libnl-3-dev, libnl-genl-3-dev, libnl-nf-3-dev, libpcre2-dev, libpopt-dev, libsnmp-dev, libssl-dev, libsystemd-dev, linux-libc-dev, pkg-config
Package-List:
 keepalived deb admin optional arch=any
Checksums-Sha1:
 ec5f603e13c2704070d0f5be79ef7d85b311e15b 1180180 keepalived_2.2.7.orig.tar.gz
 0540ce09e4f2a59062297cc633f0c615bb122594 8080 keepalived_2.2.7-1.debian.tar.xz
Checksums-Sha256:
 c61940d874154a560a54627ecf7ef47adebdf832164368d10bf242a4d9b7d49d 1180180 keepalived_2.2.7.orig.tar.gz
 4b3b57d0dea79d717e07dd962aa303c7a131f55b2a87be984f5e578c2836c703 8080 keepalived_2.2.7-1.debian.tar.xz
Files:
 5f310b66a043a1fb31acf65af15e95bc 1180180 keepalived_2.2.7.orig.tar.gz
 895e0777e8b5ffbd988e7c184b007ede 8080 keepalived_2.2.7-1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQJGBAEBCAAwFiEErvI0h2bzccaJpzYAlaQv6DU1JfkFAmIsubkSHGJlcm5hdEBk
ZWJpYW4ub3JnAAoJEJWkL+g1NSX5sAAP/06c3SQ2ClSNDJpNSySQtqPEUyD7WwUs
dSuznEEEGibehvTVNv8aQvV3sBRH7hGe8V/CZPTBdtnqp9RUKtmIhHtJyxjlFvcu
kyAvSsuNrcSNDR7ViQNBJ/rKLhCXKO6EyjllHFaICScXJ61u0BGZdMpFHjFONp5J
6vPVwhHDjZxnvSKsFZPMSvU/g3NeT8MOVn22XXACtFftTZZyTeEKJdenzcvaROyv
Pu/8f5/3B1eg3bZiX++ykQUmDPJXcKyITiTTrVZLqRTPB6ppXxVSFY4p6zzEjz3Z
vfcRNC91YrkXzi9Lnqz0QDddO6Dbu8/AuUX98i+8ZCPKWGYhV+rRSAf+mIe1LQGG
QH+mCc4vfJNZJABT9D5s3ebraa1GI9ZMBVblv4RtGoNEPhD9xG7rTW1q/lcxebvY
vdKJeDXB1uh4Q293IE9s4gztMCaNdAtWE8Q7Rn9KljNzH3zHAd8FLHTAmq0AivX5
4OMyc3KAFbICw3TiJHuX0xJcZIytYaZJw+ElOFrecehSIsLsghYnjkxK580U+PcE
WERfHb9T8zJru08hT2IuRaeDesW4Hd90ABnnY9OwMNsemPxVco6t2oGcU419E+d2
tp8xT4nj90pBc3oIVyBYKy/obK2pYJQ/C4qUjlUpaWUsOkrvyjDdBmFqD1ACys2c
Ic/Y45fh0q/b
=C+9f
-----END PGP SIGNATURE-----
