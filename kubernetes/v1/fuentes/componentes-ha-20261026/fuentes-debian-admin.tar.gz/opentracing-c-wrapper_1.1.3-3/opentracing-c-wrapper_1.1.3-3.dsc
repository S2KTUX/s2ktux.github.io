-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: opentracing-c-wrapper
Binary: libopentracing-c-wrapper-dev, libopentracing-c-wrapper0
Architecture: any
Version: 1.1.3-3
Maintainer: Stephen Gelman <ssgelm@debian.org>
Homepage: https://github.com/haproxytech/opentracing-c-wrapper/
Standards-Version: 4.5.1
Vcs-Browser: https://salsa.debian.org/ssgelm/opentracing-c-wrapper
Vcs-Git: https://salsa.debian.org/ssgelm/opentracing-c-wrapper.git
Build-Depends: debhelper-compat (= 13), pkg-config, libopentracing-dev
Package-List:
 libopentracing-c-wrapper-dev deb libdevel optional arch=any
 libopentracing-c-wrapper0 deb libs optional arch=any
Checksums-Sha1:
 1c5d47b22366b047334667cd4c3dee59eca0ae1e 45747 opentracing-c-wrapper_1.1.3.orig.tar.gz
 8427b29c71032e041bfdd4f5e1fde89e04277958 2928 opentracing-c-wrapper_1.1.3-3.debian.tar.xz
Checksums-Sha256:
 f9daf9386627d552d574cd2032e6725fe1dd29dc51d5abe34e0d7d00094c196e 45747 opentracing-c-wrapper_1.1.3.orig.tar.gz
 9d00e3e369fa4e7bfb8112b49495c251879715ff02bfe3f9c8b960951c9cc9be 2928 opentracing-c-wrapper_1.1.3-3.debian.tar.xz
Files:
 33d9a9d567d08a5c5a589781d95e2bc9 45747 opentracing-c-wrapper_1.1.3.orig.tar.gz
 d0668fd163dd166f057202fd31ee9d14 2928 opentracing-c-wrapper_1.1.3-3.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQJGBAEBCgAwFiEEPwDop1BN06KlsbfijqM4hED8f1wFAmGNZOMSHHNzZ2VsbUBk
ZWJpYW4ub3JnAAoJEI6jOIRA/H9cNuYP/ROXJf/fug/N/vqWPgpNXVtZPzyj8i/R
u+mhP1vMMpDpzEagjTdyBXT+cvgLuPyKdmbVHExpc/mXpt7jqFPGowhUlpSoo+Sj
q4PWeA1FmqaChEcCOtuGasmjYQxbilWKL8kM4QNFwnImjum0musjdnVtajYqgfH7
Pc3TM7UXPTOgdTRTJKxy298wqUlhUsXP0M4nAIRB9fqZd+H7YDri8v2zxtcs4Fr3
WT/p3RYv2kgq4SFL0z7AfObw92MZG+wj+t0+d1nqUlNc/g6GNxy8DNjMFwKsx+pB
d2Dn063S36doRxqgzFGb8N2mL4zL1fERwJvUS8OdMxWU7bGNPbT1CSL+bS19UJC5
4qI4uBAjKcsCdh+If/+Pfn2WfEyVIeRsXkIbaB/c3lKmo81DLuCliiguMFLIAgDH
grrXkN2ldPBhjxX+r1bDhxyXxe8JCntwc5qaG3iHXMz90XkmBIJhU0fLCJDUPTQD
u+VmfZvJs1V9JRgh6YNekezVXcGLx501gpFXTH7bit7XyBCmfjeU+4LkV7BygQJZ
+eepLQRBX6OTK4VMKTjPveQ8i/UPm/JKyQcRdhLSxE2ySoqC6S9o4Cfw+GH4xayJ
ygTBhk5MrPfSppNlP5gFju4E9uu0BQy/e7PlsyMLArZJMoJaderCR80GSFOSvjXe
jZd6d/l39JYK
=21mq
-----END PGP SIGNATURE-----
