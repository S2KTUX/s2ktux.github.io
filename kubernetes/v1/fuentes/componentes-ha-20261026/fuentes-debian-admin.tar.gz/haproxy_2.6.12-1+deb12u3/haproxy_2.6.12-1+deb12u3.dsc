-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: haproxy
Binary: haproxy, haproxy-doc, vim-haproxy
Architecture: any all
Version: 2.6.12-1+deb12u3
Maintainer: Debian HAProxy Maintainers <team+haproxy@tracker.debian.org>
Uploaders: Apollon Oikonomopoulos <apoikos@debian.org>, Prach Pongpanich <prach@debian.org>, Vincent Bernat <bernat@debian.org>
Homepage: http://www.haproxy.org/
Standards-Version: 4.4.1
Vcs-Browser: https://salsa.debian.org/haproxy-team/haproxy
Vcs-Git: https://salsa.debian.org/haproxy-team/haproxy.git
Testsuite: autopkgtest
Testsuite-Triggers: apache2, gnutls-bin, socat, ssl-cert, wget
Build-Depends: debhelper-compat (= 12), libpcre2-dev, libssl-dev, liblua5.3-dev, libsystemd-dev [linux-any], python3-sphinx, libopentracing-c-wrapper-dev, pkg-config
Build-Depends-Indep: python3, python3-mako
Package-List:
 haproxy deb net optional arch=any
 haproxy-doc deb doc optional arch=all
 vim-haproxy deb net optional arch=all
Checksums-Sha1:
 d12745cff8fbcdd82d4d6fe1fc679d3bdb871c4c 4060878 haproxy_2.6.12.orig.tar.gz
 af3153f30a72ea127a5c42fb82d7fb8173f2775d 88112 haproxy_2.6.12-1+deb12u3.debian.tar.xz
Checksums-Sha256:
 58f9edb26bf3288f4b502658399281cc5d6478468bd178eafe579c8f41895854 4060878 haproxy_2.6.12.orig.tar.gz
 90667334095484aea4225ebdebf027505c77366ab1c4dbf06bcecdcc9eae356a 88112 haproxy_2.6.12-1+deb12u3.debian.tar.xz
Files:
 215f5c315e5881f19b974c1d48581098 4060878 haproxy_2.6.12.orig.tar.gz
 d03b68879de2ceb9b93339de62653fb9 88112 haproxy_2.6.12-1+deb12u3.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQJGBAEBCgAwFiEErvI0h2bzccaJpzYAlaQv6DU1JfkFAmjfjCgSHGJlcm5hdEBk
ZWJpYW4ub3JnAAoJEJWkL+g1NSX5sY4P/jNOR4b6p2KwwnIt/0hNreXEYRY4GTPz
MnY/R4y0CadAR3YDyhMmWctOYnv/e3UiyLW0Tkv475IqdUy7WDBifGdFmx6HCLEj
LrVtKL8JFGCjMcAxzDQwyKPn+RkYIX3E4/NiLOYBXGNZAWqQM9loRFzj3spTOsrh
jhjlEb1yO1vU2CGGLr476Xigge+aNwTEGEPb97Z5P5Ig23CYq/8PNao5hph1k+Pi
QOWrsDpsipviT7i/sCg9SckmvJAlSANM48hlkNmq9Ghxl9fn/hnJVz5tfT21zBR6
yPx9frx2CeRxMMcgYqZU0jO7Azn99wN5zIM+QaG9ghNiWXFWCHauCt3iFVrKlSq4
G98uivpLQfFDeU1nCKwCCiW34GbWATnj0zw+WZZEapVJLjJ9xjZFF36/JMwnXt6I
niletboBKiRXFJQ8eTPWVp4EHKdy2P8v2stSBBPTE8yqoaeIlPML+a56YUmry+UD
joMVo0qhS2i1+Dz7NuX4+YiBGZu2IAe2EenO1b/fGVxNjx0G1iHphrnXVd2aqg72
NJ8xCXOSU8CGoJribjrPVKdDyqdP10WkBDKwWt5oCBPqbuzL+3BzuC3xf4k23076
Tq0q7QPHOdcmDU/jSf6sgBhXyU/BEidtUEVfKai2jLpvesKxCPO5Q8i8dT7Ifo4o
61B5mIw5BlV2
=TlYw
-----END PGP SIGNATURE-----
