-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: lua5.3
Binary: lua5.3, liblua5.3-dev, liblua5.3-0, liblua5.3-0-dbg
Architecture: any
Version: 5.3.6-2
Maintainer: Debian Lua Team <pkg-lua-devel@lists.alioth.debian.org>
Uploaders: Ondřej Surý <ondrej@debian.org>
Homepage: https://www.lua.org
Standards-Version: 3.9.8
Vcs-Browser: https://salsa.debian.org/lua-team/lua5.3
Vcs-Git: https://salsa.debian.org/lua-team/lua5.3.git
Build-Depends: debhelper (>= 10), quilt (>= 0.40), libtool-bin, libreadline-dev
Package-List:
 liblua5.3-0 deb libs optional arch=any
 liblua5.3-0-dbg deb debug optional arch=any
 liblua5.3-dev deb libdevel optional arch=any
 lua5.3 deb interpreters optional arch=any
Checksums-Sha1:
 f27d20d6c81292149bc4308525a9d6733c224fa5 303770 lua5.3_5.3.6.orig.tar.gz
 3722581b1d013fa0708ca2eb7fca48066db499be 7628 lua5.3_5.3.6-2.debian.tar.xz
Checksums-Sha256:
 fc5fd69bb8736323f026672b1b7235da613d7177e72558893a0bdcd320466d60 303770 lua5.3_5.3.6.orig.tar.gz
 0808119db67b1c81d0cf71f43df92623e09891439d9f454cb7183db89f63b721 7628 lua5.3_5.3.6-2.debian.tar.xz
Files:
 83f23dbd5230140a3770d5f54076948d 303770 lua5.3_5.3.6.orig.tar.gz
 5e437ba7ef8b0b48a51d70b345a45e93 7628 lua5.3_5.3.6-2.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEsjhixBXWVlpOhsvXV5wWDUyeI+gFAmOUlhsACgkQV5wWDUye
I+i4+BAAtjGhvBACcEhlQ6kgEtp33l/mWIpVKCi/Uof/oOha3xqXeP4Bnoo2rWfK
br0mEO7U7JKAWdPOs51+085B+bBd2/5Utpqa3tFBr23W9j2tzRHttyfxArVpvaHI
KTJGPcXLyHFrX43IKLCiZZ/ViTHNIb/iEgtHwbtkbZGjrss2QVKgLTgQzP3w3yKG
iaRKCzwMDGWYpEfiF6U36YJQ7r/2V4yySNz6ZccE2WFLhOL+b/x4UOE6QSYY6GCh
OeV91Am3UPjl1IDvtKUaU0+borvPKXtgGXB4Y8g4oljdJYP9joHfw3Rm/VDFRAGx
YwLHWu7UZdnkZepHDAHhKVn6j6VWBPhxL8GPNWLtYaYo6uj8JbsVaTfBnfHzaxdH
SeSPJ/FimN+okxC3OQiR9DRpCn8kspW2E/xPXZtybdieOgONGF7AEhibQgXdtrkG
EEzKjga33UnvITGOvN2onrJ2wzMWuu8+aBmP7+/lWgIRpMUKGjoE3w/brkNxNkXc
CcnVDlXdm8NGHFH67LVV2/FCpJ3Hx20c6dCtPsvuBnGRru/xQDthpe0SrlwlPhlr
54mIijH9PDx4MY25hgfyB89x5QTUNS/BB+S0CRaPxWTAAdvR/pJDDJHuieovTYyL
ltTBNofQs2aj6cuTF78LIBGN9A9iRdjKl5KJaAupZWKUEVPxnyQ=
=K2HX
-----END PGP SIGNATURE-----
