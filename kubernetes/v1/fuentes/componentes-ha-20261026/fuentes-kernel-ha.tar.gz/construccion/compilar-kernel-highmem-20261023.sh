#!/bin/bash
# Candidato privado: no sustituye kernels ni sesiones publicados.
set -Eeuo pipefail
base=/home/s2ktux/kubernetes-browser-build-20261012
source=/home/s2ktux/docker-v86-build-20261011/kernel-source
original="$base/kernel-cka-v1"
out="$base/kernel-cka-highmem-v1"
destination=/mnt/d/RIVALIA/prototipo-contenedores-web/kubernetes-real/debian/kernel/highmem-v1
test -r "$original/.config"
test ! -e "$destination"
if test -d "$out"; then
  # Reanudación de la copia privada que se detuvo por permisos de initramfs.
  cmp -s "$original/.config" "$out/.config"
  cp -a "$original/." "$out/"
else
  cp -a "$original" "$out"
fi
"$source/scripts/config" --file "$out/.config" --disable NOHIGHMEM --enable HIGHMEM4G --set-str LOCALVERSION '-s2ktux-cka-highmem'
make -C "$source" O="$out" ARCH=x86 olddefconfig
grep -qx 'CONFIG_HIGHMEM4G=y' "$out/.config"
grep -qx 'CONFIG_HIGHMEM=y' "$out/.config"
make -C "$source" O="$out" ARCH=x86 -j4 bzImage >"$base/kernel-cka-highmem-v1.log" 2>&1
mkdir -p "$destination"
install -m 644 "$out/arch/x86/boot/bzImage" "$destination/vmlinuz"
install -m 644 "$out/.config" "$destination/kernel.config"
install -m 644 "$out/modules.builtin" "$destination/modules.builtin"
install -m 644 "$out/modules.builtin.modinfo" "$destination/modules.builtin.modinfo"
sha256sum "$destination/vmlinuz" "$destination/kernel.config"
