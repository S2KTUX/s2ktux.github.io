#!/bin/bash
# Kernel privado nuevo; no cambia el kernel ni discos de Linux/Docker.
set -Eeuo pipefail
base=/home/s2ktux/kubernetes-browser-build-20261012
original=/home/s2ktux/docker-v86-build-20261011/kernel-32-out
source=/home/s2ktux/docker-v86-build-20261011/kernel-source
out="$base/kernel-cka-v1"
destination=/mnt/d/RIVALIA/prototipo-contenedores-web/kubernetes-real/debian/kernel/v1
test -r "$original/.config"
grep -qx '# CONFIG_PACKET is not set' "$original/.config"
test ! -e "$out"
test ! -e "$destination"
cp -a "$original" "$out"
"$source/scripts/config" --file "$out/.config" --enable PACKET --enable PACKET_DIAG --set-str LOCALVERSION '-s2ktux-cka'
make -C "$source" O="$out" ARCH=x86 olddefconfig
grep -qx 'CONFIG_PACKET=y' "$out/.config"
make -C "$source" O="$out" ARCH=x86 -j4 bzImage >"$base/kernel-cka-v1.log" 2>&1
mkdir -p "$destination"
install -m 644 "$out/arch/x86/boot/bzImage" "$destination/vmlinuz"
install -m 644 "$out/.config" "$destination/kernel.config"
install -m 644 "$out/modules.builtin" "$destination/modules.builtin"
install -m 644 "$out/modules.builtin.modinfo" "$destination/modules.builtin.modinfo"
sha256sum "$destination/vmlinuz" "$destination/kernel.config" "$destination/modules.builtin" "$destination/modules.builtin.modinfo"
