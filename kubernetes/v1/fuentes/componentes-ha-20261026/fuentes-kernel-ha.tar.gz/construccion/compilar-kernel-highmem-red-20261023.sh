#!/bin/bash
# Candidato HA frío; conserva todos los kernels/capturas anteriores.
set -Eeuo pipefail
base=/home/s2ktux/kubernetes-browser-build-20261012
source="$base/kernel-cka-net-v2-source"
original_source=/home/s2ktux/docker-v86-build-20261011/kernel-source
original="$base/kernel-cka-highmem-v1"
out="$base/kernel-cka-highmem-net-v1"
destination=/mnt/d/RIVALIA/prototipo-contenedores-web/kubernetes-real/debian/kernel/highmem-net-v1
patchfile=/mnt/d/RIVALIA/prototipo-contenedores-web/kubernetes-real/debian/kernel-ne2k-watchdog.patch
test -r "$original/.config"
grep -qx 'CONFIG_HIGHMEM4G=y' "$original/.config"
test ! -e "$out"
test ! -e "$destination"
patch --dry-run --reverse --batch --fuzz=0 -d "$source" -p1 <"$patchfile"
cp -a --reflink=auto "$original" "$out"
# Solo adaptar rutas de esta copia de Kbuild para reutilizar los objetos.
find "$out" -type f -name '.*.cmd' -exec sed -i "s|$original_source|$source|g; s|$original|$out|g" {} +
make -C "$source" O="$out" ARCH=x86 olddefconfig >"$base/kernel-cka-highmem-net-v1.log" 2>&1
make -C "$source" O="$out" ARCH=x86 -j2 bzImage >>"$base/kernel-cka-highmem-net-v1.log" 2>&1
cmp "$original/.config" "$out/.config"
mkdir -p "$destination"
for file in .config modules.builtin modules.builtin.modinfo; do
 name="$file"; test "$file" != .config || name=kernel.config
 install -m 644 "$out/$file" "$destination/$name"
done
install -m 644 "$out/arch/x86/boot/bzImage" "$destination/vmlinuz"
sha256sum "$destination/vmlinuz" "$destination/modules.builtin" "$destination/modules.builtin.modinfo"
