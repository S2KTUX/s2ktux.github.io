#!/bin/bash
set -Eeuo pipefail
base=/home/s2ktux/kubernetes-browser-build-20261012
out="$base/kernel-cka-highmem-net-v1"
source="$base/kernel-cka-net-v2-source"
destination=/mnt/d/RIVALIA/prototipo-contenedores-web/kubernetes-real/debian/kernel/highmem-net-v2
test "$(realpath "$out")" = /home/s2ktux/kubernetes-browser-build-20261012/kernel-cka-highmem-net-v1
test ! -e "$destination"
test -f "$out/drivers/net/ethernet/8390/ne2k-pci.o"
test -f "$out/drivers/net/ethernet/8390/.ne2k-pci.o.cmd"
test ! -L "$out/drivers/net/ethernet/8390/ne2k-pci.o"
# La caché copiada tenía un objeto más reciente que el fuente parcheado.
# Quitar solo estos dos productos reproducibles obliga a compilar ese driver.
# No se borra fuente ni ningún kernel/captura guardados en Windows.
rm -- "$out/drivers/net/ethernet/8390/ne2k-pci.o" "$out/drivers/net/ethernet/8390/.ne2k-pci.o.cmd"
make -C "$source" O="$out" ARCH=x86 -j2 bzImage >"$base/kernel-cka-highmem-net-v2.log" 2>&1
nm "$out/vmlinux" | grep tx_watchdog_ms
mkdir "$destination"
install -m 644 "$out/arch/x86/boot/bzImage" "$destination/vmlinuz"
install -m 644 "$out/.config" "$destination/kernel.config"
install -m 644 "$out/modules.builtin" "$destination/modules.builtin"
install -m 644 "$out/modules.builtin.modinfo" "$destination/modules.builtin.modinfo"
sha256sum "$destination/vmlinuz" "$destination/modules.builtin" "$destination/modules.builtin.modinfo"
