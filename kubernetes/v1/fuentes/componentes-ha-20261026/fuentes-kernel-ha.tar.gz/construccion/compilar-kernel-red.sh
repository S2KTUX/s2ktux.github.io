#!/bin/bash
# Build privado en directorios nuevos; conservar fuente/kernel/capturas v1.
set -Eeuo pipefail
base=/home/s2ktux/kubernetes-browser-build-20261012
original_source=/home/s2ktux/docker-v86-build-20261011/kernel-source
source="$base/kernel-cka-net-v2-source"
out="$base/kernel-cka-net-v2-out"
original_out="$base/kernel-cka-v1"
workspace=/mnt/d/RIVALIA/prototipo-contenedores-web/kubernetes-real/debian
destination="$workspace/kernel/v2"
test ! -e "$destination"
test -s "$original_out/.config"
test "$(sha256sum "$workspace/kernel/v1/vmlinuz" | cut -d ' ' -f1)" = 7266ac03849dd287b8e672d8ae9e882d6eb3c1bcd5e88d951132c2614b56cd96
if test "${1-}" = resume; then
 test -d "$source"; test -d "$out"
 patch --dry-run --reverse --batch --fuzz=0 -d "$source" -p1 <"$workspace/kernel-ne2k-watchdog.patch"
elif test -z "${1-}"; then
 test ! -e "$source"; test ! -e "$out"
 cp -a --reflink=auto "$original_source" "$source"
 cp -a --reflink=auto "$original_out" "$out"
 # Transformación reproducible del fuente copiado, nunca del original.
 patch --batch --fuzz=0 -d "$source" -p1 <"$workspace/kernel-ne2k-watchdog.patch"
else exit 1; fi
# Kbuild guarda rutas absolutas en su caché de órdenes. Adaptar solo esas
# referencias de la copia evita recompilar todo por haber cambiado de carpeta.
test "$out" = /home/s2ktux/kubernetes-browser-build-20261012/kernel-cka-net-v2-out
find "$out" -type f -name '.*.cmd' -exec sed -i "s|$original_source|$source|g; s|$original_out|$out|g" {} +
make -C "$source" O="$out" ARCH=x86 olddefconfig >"$base/kernel-cka-net-v2.log" 2>&1
make -C "$source" O="$out" ARCH=x86 -j2 bzImage >>"$base/kernel-cka-net-v2.log" 2>&1
cmp "$original_out/.config" "$out/.config"
mkdir "$destination"
install -m 644 "$out/arch/x86/boot/bzImage" "$destination/vmlinuz"
install -m 644 "$out/.config" "$destination/kernel.config"
install -m 644 "$out/modules.builtin" "$destination/modules.builtin"
install -m 644 "$out/modules.builtin.modinfo" "$destination/modules.builtin.modinfo"
sha256sum "$destination/vmlinuz" "$destination/kernel.config"
