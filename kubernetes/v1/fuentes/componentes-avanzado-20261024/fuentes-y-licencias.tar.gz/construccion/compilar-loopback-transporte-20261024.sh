#!/bin/bash
set -Eeuo pipefail
build=/home/s2ktux/kubernetes-browser-build-20261012
source="$build/kubernetes-1.36.5"
out="$build/loopback-transport-1.36-v2-20261024"
destination=/mnt/d/RIVALIA/prototipo-contenedores-web/kubernetes-real/debian/transportes-qa/loopback-v2
test -f "$out/overlay.json"
test ! -e "$out/kube-browser-shared"
test ! -e "$destination"
export PATH="$build/go/bin:$PATH" GOCACHE="$build/cache" GOMODCACHE="$build/modules" GOTOOLCHAIN=local
export GOOS=linux GOARCH=386 CGO_ENABLED=0 GOMAXPROCS=1 GOMEMLIMIT=1000MiB
cd "$source"
# Recheck the latest tests, including HTTP/2 and a denied bearer token.
nice -n 19 go test -p 1 -mod=vendor -overlay "$out/overlay.json" -run '^TestBrowserTransportRealCacheAndTLS$' k8s.io/client-go/transport >"$out/tests-transport-final.log" 2>&1
cat "$out/tests-transport-final.log"
flags='-s -w -X k8s.io/component-base/version.gitVersion=v1.36.5 -X k8s.io/component-base/version.gitMajor=1 -X k8s.io/component-base/version.gitMinor=36 -X k8s.io/component-base/version.gitTreeState=dirty -X k8s.io/client-go/pkg/version.gitVersion=v1.36.5 -X k8s.io/client-go/pkg/version.gitMajor=1 -X k8s.io/client-go/pkg/version.gitMinor=36'
nice -n 19 go build -p 1 -mod=vendor -overlay "$out/overlay.json" -trimpath -ldflags "$flags" -o "$out/kube-browser-shared" ./cmd/s2ktux-browser-v2 >"$out/build.log" 2>&1
file "$out/kube-browser-shared"
cd "$out"
sha256sum kube-browser-shared >SHA256SUMS
tar -czf paquete.tar.gz kube-browser-shared SHA256SUMS
mkdir "$destination"
cp paquete.tar.gz "$destination/paquete.tar.gz"
sha256sum kube-browser-shared paquete.tar.gz
