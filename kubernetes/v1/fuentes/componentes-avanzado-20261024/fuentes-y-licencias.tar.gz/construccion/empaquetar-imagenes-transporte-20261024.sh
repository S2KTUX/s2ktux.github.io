#!/bin/bash
# Build a real OCI archive without another daemon. Existing blobs stay intact;
# replace only COPY's executable layer and recompute every affected digest.
set -Eeuo pipefail
build=/home/s2ktux/kubernetes-browser-build-20261012
target="$build/upgrade-images-transport-v2-20261024"
original="$build/upgrade-images-v1/imagenes.tar.gz"
candidate="$build/loopback-transport-1.36-v2-20261024/kube-browser-shared"
oldmanifest=710d5d4700c097394fe13f87cc27783d0abcab6b76a15b15e7974bbbd0df5c90
oldconfig=657ed256a9bc7d18c94673cc0671486aecc4b7b15b116c10b82faec589462da5
oldcopy=e713672c4b6c4acb60150ad90ad331e90237d68985c50635fe41135ff36e3d7c
binarysha=6c0d826692bcf9c042f7d2de8e75ac063f15b7eb4f18925c7f03cf4e23fd9c7c
test ! -e "$target"
test "$(sha256sum "$original" | cut -d ' ' -f1)" = 9c916e4113fa1a6dadc84903651da059c0ee956eec2f0f0c789259ee8713a7a8
test "$(sha256sum "$candidate" | cut -d ' ' -f1)" = "$binarysha"
mkdir -p "$target/original" "$target/oci/blobs/sha256" "$target/layer/opt/kubernetes/bin"
tar -xzf "$original" --no-same-owner --no-same-permissions -C "$target/original"
for blob in "$target/original/blobs/sha256/"*; do
 test "$(sha256sum "$blob" | cut -d ' ' -f1)" = "${blob##*/}"
done
jq -e --arg config "sha256:$oldconfig" --arg copy "sha256:$oldcopy" '.config.digest==$config and .layers[1].digest==$copy and (.layers|length)==3' "$target/original/blobs/sha256/$oldmanifest"
jq -e '.architecture=="386" and .os=="linux" and (.rootfs.diff_ids|length)==3' "$target/original/blobs/sha256/$oldconfig"
install -m 755 "$candidate" "$target/layer/opt/kubernetes/bin/kube-browser-shared"
tar --sort=name --owner=0 --group=0 --numeric-owner --mtime=@0 -cf "$target/executable.tar" -C "$target/layer" opt
diffid=$(sha256sum "$target/executable.tar" | cut -d ' ' -f1)
gzip -n -1 -c "$target/executable.tar" >"$target/executable.tar.gz"
layerhash=$(sha256sum "$target/executable.tar.gz" | cut -d ' ' -f1)
layersize=$(stat -c %s "$target/executable.tar.gz")
cp "$target/executable.tar.gz" "$target/oci/blobs/sha256/$layerhash"
jq --arg diff "sha256:$diffid" --arg bin "$binarysha" '
 .rootfs.diff_ids[1]=$diff |
 .config.Labels["org.opencontainers.image.description"]="S2KTUX custom linux/386: ECDSA loopback and bounded verified TLS transport; not an official Kubernetes image" |
 .config.Labels["org.s2ktux.binary.sha256"]=$bin |
 .history[1].created_by="COPY verified loopback-transport-v2 executable /opt/kubernetes/bin/kube-browser-shared" |
 .history[1].comment="S2KTUX OCI layer reconstruction, 2026-10-24"
' "$target/original/blobs/sha256/$oldconfig" >"$target/config.json"
configsha=$(sha256sum "$target/config.json" | cut -d ' ' -f1)
configsize=$(stat -c %s "$target/config.json")
cp "$target/config.json" "$target/oci/blobs/sha256/$configsha"
jq --arg config "sha256:$configsha" --argjson configsize "$configsize" --arg layer "sha256:$layerhash" --argjson layersize "$layersize" '
 .config.digest=$config | .config.size=$configsize | .layers[1].digest=$layer | .layers[1].size=$layersize
' "$target/original/blobs/sha256/$oldmanifest" >"$target/core-manifest.json"
manifestsha=$(sha256sum "$target/core-manifest.json" | cut -d ' ' -f1)
manifestsize=$(stat -c %s "$target/core-manifest.json")
cp "$target/core-manifest.json" "$target/oci/blobs/sha256/$manifestsha"
jq --arg old "sha256:$oldmanifest" --arg digest "sha256:$manifestsha" --argjson size "$manifestsize" '
 .manifests |= map(if .digest==$old then .digest=$digest | .size=$size else . end)
' "$target/original/index.json" >"$target/oci/index.json"
jq --arg old "blobs/sha256/$oldconfig" --arg config "blobs/sha256/$configsha" --arg layer "blobs/sha256/$layerhash" '
 map(if .Config==$old then .Config=$config | .Layers[1]=$layer else . end)
' "$target/original/manifest.json" >"$target/oci/manifest.json"
cp "$target/original/oci-layout" "$target/oci/oci-layout"
# Copy only referenced blobs. The old 35 MB executable layer is not shipped.
jq -r '.manifests[].digest' "$target/oci/index.json" | sort -u >"$target/manifests.list"
while read -r digest; do
 sha=${digest#sha256:}; [[ "$sha" =~ ^[a-f0-9]{64}$ ]]
 if test ! -e "$target/oci/blobs/sha256/$sha"; then cp "$target/original/blobs/sha256/$sha" "$target/oci/blobs/sha256/$sha"; fi
 jq -r '.config.digest,.layers[].digest' "$target/oci/blobs/sha256/$sha" >>"$target/references.list"
done <"$target/manifests.list"
sort -u "$target/references.list" >"$target/references-unique.list"
while read -r digest; do
 sha=${digest#sha256:}; [[ "$sha" =~ ^[a-f0-9]{64}$ ]]
 if test ! -e "$target/oci/blobs/sha256/$sha"; then cp "$target/original/blobs/sha256/$sha" "$target/oci/blobs/sha256/$sha"; fi
done <"$target/references-unique.list"
test ! -e "$target/oci/blobs/sha256/$oldcopy"
for blob in "$target/oci/blobs/sha256/"*; do test "$(sha256sum "$blob" | cut -d ' ' -f1)" = "${blob##*/}"; done
tar --sort=name --owner=0 --group=0 --numeric-owner --mtime=@0 -cf - -C "$target/oci" . | gzip -n -1 >"$target/imagenes.tar.gz"
archivesha=$(sha256sum "$target/imagenes.tar.gz" | cut -d ' ' -f1)
bytes=$(stat -c %s "$target/imagenes.tar.gz")
jq -n --arg archive "$archivesha" --arg core "$manifestsha" --arg binary "$binarysha" --argjson bytes "$bytes" '{localTestingOnly:true,version:"1.36.5",archiveSha256:$archive,coreImageSha256:$core,binarySha256:$binary,bytes:$bytes,proxyImageSha256:"eba002eefd9e29036d0d1596c854e59ebdcb29c12054d0e8a931ee41242b3060"}' >"$target/paquete.json"
cat "$target/paquete.json"
