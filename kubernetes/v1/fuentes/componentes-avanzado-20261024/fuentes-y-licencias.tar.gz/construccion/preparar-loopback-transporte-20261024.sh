#!/bin/bash
set -Eeuo pipefail
build=/home/s2ktux/kubernetes-browser-build-20261012
source="$build/kubernetes-1.36.5"
out="$build/loopback-transport-1.36-v2-20261024"
project=/mnt/d/RIVALIA/prototipo-contenedores-web/kubernetes-real
test ! -e "$out"
mkdir "$out"
# Exact single insertion; the complete upstream cache/GC/rotation stays.
awk '
 $0=="\tvar transport http.RoundTripper = httpTransport" {print "\tbrowserLoopbackTransportBudget(config, httpTransport)"; calls++}
 {print}
 END {if(calls!=1)exit 42}
' "$source/staging/src/k8s.io/client-go/transport/cache.go" >"$out/cache.go"
awk -f "$project/debian/overlay-loopback-1.36.awk" "$source/staging/src/k8s.io/apiserver/pkg/server/options/serving_with_loopback.go" >"$out/serving_with_loopback.go"
sed -n '/^func browserLoopbackCertificate/,$p' "$project/lanzador/serving_with_loopback.go" >>"$out/serving_with_loopback.go"
# The ineffective WrapTransport helper is intentionally not present.
printf '{"Replace":{"%s":"%s","%s":"%s","%s":"%s","%s":"%s","%s":"%s"}}\n' \
 "$source/staging/src/k8s.io/apiserver/pkg/server/options/serving_with_loopback.go" "$out/serving_with_loopback.go" \
 "$source/staging/src/k8s.io/apiserver/pkg/server/options/serving_with_loopback_browser_test.go" "$project/lanzador/serving_with_loopback_browser_test.go" \
 "$source/staging/src/k8s.io/client-go/transport/cache.go" "$out/cache.go" \
 "$source/staging/src/k8s.io/client-go/transport/browser_loopback_transport.go" "$project/lanzador/browser_loopback_transport.go" \
 "$source/staging/src/k8s.io/client-go/transport/browser_loopback_transport_test.go" "$project/lanzador/browser_loopback_transport_test.go" >"$out/overlay.json"
export PATH="$build/go/bin:$PATH" GOCACHE="$build/cache" GOMODCACHE="$build/modules" GOTOOLCHAIN=local
export GOOS=linux GOARCH=386 CGO_ENABLED=0 GOMAXPROCS=1 GOMEMLIMIT=1000MiB
cd "$source"
nice -n 19 go test -p 1 -mod=vendor -overlay "$out/overlay.json" -run '^TestBrowserTransportRealCacheAndTLS$' k8s.io/client-go/transport >"$out/tests-transport.log" 2>&1
cat "$out/tests-transport.log"
nice -n 19 go test -p 1 -mod=vendor -overlay "$out/overlay.json" -run '^Test(BrowserLoopback|ApplyToConfig|EmptyMainCert)' k8s.io/apiserver/pkg/server/options >"$out/tests-options.log" 2>&1
cat "$out/tests-options.log"
