#!/bin/bash
set -Eeuo pipefail
build=/home/s2ktux/kubernetes-browser-build-20261012
source="$build/kubernetes-1.35.9"
project=/mnt/d/RIVALIA/prototipo-contenedores-web/kubernetes-real
out="$build/loopback-transport-1.35-v1-20261024"
test ! -e "$out"
test "$(sha256sum "$source/staging/src/k8s.io/client-go/transport/cache.go" | cut -d ' ' -f1)" = 0453421f8397ca0aefd2c6e6213a09752c39bf3b09cccc1743522029f61333f7
mkdir "$out"
awk '
 /^\ttransport := utilnet.SetTransportDefaults/ {found=1}
 /^\tif canCache \{$/ && found {print "\tbrowserLoopbackTransportBudget(config, transport)"; calls++}
 {print}
 END {if(calls!=1)exit 42}
' "$source/staging/src/k8s.io/client-go/transport/cache.go" >"$out/cache.go"
# Keep the exact ECDSA overlay used by the existing 1.35 build. Only the
# internal verified transport is new; auth, hooks and health remain intact.
printf '{"Replace":{"%s":"%s","%s":"%s","%s":"%s","%s":"%s"}}\n' \
 "$source/staging/src/k8s.io/apiserver/pkg/server/options/serving_with_loopback.go" "$project/lanzador/serving_with_loopback.go" \
 "$source/staging/src/k8s.io/client-go/transport/cache.go" "$out/cache.go" \
 "$source/staging/src/k8s.io/client-go/transport/browser_loopback_transport.go" "$project/lanzador/browser_loopback_transport.go" \
 "$source/staging/src/k8s.io/client-go/transport/browser_loopback_transport_test.go" "$project/lanzador/browser_loopback_transport_test.go" >"$out/overlay.json"
export PATH="$build/go/bin:$PATH" GOCACHE="$build/cache" GOMODCACHE="$build/modules" GOTOOLCHAIN=local
export GOOS=linux GOARCH=386 CGO_ENABLED=0 GOMAXPROCS=1 GOMEMLIMIT=1000MiB
cd "$source"
nice -n 19 go test -p 1 -mod=vendor -overlay "$out/overlay.json" -run '^TestBrowserTransportRealCacheAndTLS$' k8s.io/client-go/transport >"$out/tests.log" 2>&1
cat "$out/tests.log"
flags='-s -w -X k8s.io/component-base/version.gitVersion=v1.35.9 -X k8s.io/component-base/version.gitMajor=1 -X k8s.io/component-base/version.gitMinor=35 -X k8s.io/component-base/version.gitTreeState=dirty -X k8s.io/client-go/pkg/version.gitVersion=v1.35.9 -X k8s.io/client-go/pkg/version.gitMajor=1 -X k8s.io/client-go/pkg/version.gitMinor=35'
nice -n 19 go build -p 1 -mod=vendor -overlay "$out/overlay.json" -trimpath -ldflags "$flags" -o "$out/kube-browser-shared" ./cmd/s2ktux-browser-v2 >"$out/build.log" 2>&1
cd "$out"
sha256sum kube-browser-shared >SHA256SUMS
tar -czf paquete.tar.gz kube-browser-shared SHA256SUMS
sha256sum kube-browser-shared paquete.tar.gz
file kube-browser-shared
