#!/bin/bash
set -Eeuo pipefail
build=/home/s2ktux/kubernetes-browser-build-20261012
out="$build/loopback-transport-1.35-v1-20261024"
test ! -e "$out/tests-watches.log"
export PATH="$build/go/bin:$PATH" GOCACHE="$build/cache" GOMODCACHE="$build/modules" GOTOOLCHAIN=local
export GOOS=linux GOARCH=386 CGO_ENABLED=0 GOMAXPROCS=1 GOMEMLIMIT=1000MiB
cd "$build/kubernetes-1.35.9"
nice -n 19 go test -p 1 -mod=vendor -overlay "$out/overlay.json" -run '^TestBrowserTransport(RealCacheAndTLS|HTTP2WatchesNotStarveBootstrap)$' k8s.io/client-go/transport >"$out/tests-watches.log" 2>&1
cat "$out/tests-watches.log"
