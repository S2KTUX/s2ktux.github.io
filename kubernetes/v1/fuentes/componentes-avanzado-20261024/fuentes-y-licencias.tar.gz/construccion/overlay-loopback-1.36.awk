# Generador de overlay: conservar toda la lógica upstream, incluidos healthchecks.
BEGIN { imports=0; calls=0; removed=0; pending=0; failed=0 }
function fail(){ failed=1; exit 42 }
pending==1 { if ($0!="\t\tHost:   server.LoopbackClientServerNameOverride,") fail(); pending=2; next }
pending==2 { if ($0!="\t\tMaxAge: maxAge,") fail(); pending=3; next }
pending==3 { if ($0!="\t})") fail(); pending=0; next }
$0=="import (" { print; print "\t\"bytes\"\n\t\"crypto/ecdsa\"\n\t\"crypto/elliptic\"\n\t\"crypto/rand\"\n\t\"crypto/x509\"\n\t\"crypto/x509/pkix\"\n\t\"encoding/pem\"\n\t\"math/big\""; imports++; next }
$0=="\tcertutil \"k8s.io/client-go/util/cert\"" { removed++; next }
$0=="\tcertPem, keyPem, err := certutil.GenerateSelfSignedCertKeyWithOptions(certutil.SelfSignedCertKeyOptions{" { print "\tcertPem, keyPem, err := browserLoopbackCertificate(server.LoopbackClientServerNameOverride, maxAge)"; calls++; pending=1; next }
{ print }
END { if (failed || imports!=1 || calls!=1 || removed!=1 || pending!=0) exit 42 }
