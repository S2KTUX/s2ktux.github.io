#!/bin/bash
set -Eeuo pipefail
previous=/home/s2ktux/kubernetes-browser-build-20261012/motor-jit8192-v1
candidate=/mnt/d/RIVALIA/revision-aprendizaje-20261020/motor-pic-solo-20261023
patchfile=/mnt/d/RIVALIA/prototipo-contenedores-web/kubernetes-real/debian/pic-espurio.patch
test ! -e "$candidate"
test -x "$previous/rust/bin/cargo"
mkdir "$candidate"
cp -a "$previous/source" "$candidate/source"
cd "$candidate/source"
patch --batch --fuzz=0 -p1 < "$patchfile"
# No copiar CPU/TSC del otro candidato: este ensayo cambia solamente PIC.
cmp src/rust/cpu/cpu.rs "$previous/source/src/rust/cpu/cpu.rs"
export PATH="$previous/bin:$previous/rust/bin:$PATH"
export CARGO_HOME="$previous/cargo-cache"
cargo rustc --offline --release --target wasm32-unknown-unknown -- -C linker=tools/rust-lld-wrapper -C link-args="--import-table --global-base=4096 --v86-strip-debug" -C link-args="build/softfloat.o" -C link-args="build/zstddeclib.o" -C target-feature=+bulk-memory -C target-feature=+multivalue -C target-feature=+simd128 > "$candidate/compilacion.log" 2>&1
install -m 644 build/wasm32-unknown-unknown/release/v86.wasm "$candidate/v86.wasm"
sha256sum "$candidate/v86.wasm" src/rust/cpu/pic.rs src/rust/cpu/cpu.rs
