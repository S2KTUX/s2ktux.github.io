import {build} from '../../s2ktux-site/node_modules/esbuild/lib/main.js';
import {fileURLToPath} from 'node:url';
import {stat,readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const output=new URL('motor-experimento/libv86-jit8192.mjs',import.meta.url);
try{await stat(output);throw Error('El candidato ya existe');}catch(error){if(error.code!=='ENOENT')throw error;}
await build({entryPoints:[fileURLToPath(new URL('motor-experimento/fuentes-jit8192/src/browser/starter.js',import.meta.url))],outfile:fileURLToPath(output),bundle:true,format:'esm',platform:'browser',target:'es2020',minify:true,define:{DEBUG:'false'},external:['node:*','fs','path','perf_hooks','crypto','./capstone-x86.min.js','./libwabt.cjs']});
const bytes=await readFile(output),sha256=createHash('sha256').update(bytes).digest('hex');
await writeFile(new URL('motor-experimento/front.json',import.meta.url),JSON.stringify({source:'v86-1e4f43c95, copia del constructor privado',tableEntries:8192,bytes:bytes.length,sha256,experimental:true},null,2),{flag:'wx'});
console.log(JSON.stringify({bytes:bytes.length,sha256,experimental:true}));
