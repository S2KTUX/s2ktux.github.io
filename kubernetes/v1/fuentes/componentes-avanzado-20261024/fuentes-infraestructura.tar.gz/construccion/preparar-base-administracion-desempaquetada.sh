#!/bin/bash
# Otra copia privada: preparar capas OCI en el constructor, no durante upgrade.
# No inicia Kubernetes ni modifica bases/fábricas anteriores.
set -Eeuo pipefail
if test "${1-}" != private-mounts; then
 exec unshare --mount --propagation private --fork bash "$0" private-mounts
fi
build=/home/s2ktux/kubernetes-browser-build-20261012
target="$build/debian-admin-v3"
rootfs="$target/rootfs"
test "$(readlink -m "$target")" = /home/s2ktux/kubernetes-browser-build-20261012/debian-admin-v3
test ! -e "$target"
test ! -e "$build/debian-admin-v2/rootfs/etc/kubernetes/admin.conf"
! mountpoint -q "$build/debian-admin-v2/rootfs/proc"
mkdir "$target"
cp -a --reflink=auto "$build/debian-admin-v2/rootfs" "$rootfs"
mkdir -p "$rootfs/run/preload" "$rootfs/tmp"
printf '%s\n' 'version = 3' 'disabled_plugins = ["io.containerd.cri.v1.images", "io.containerd.cri.v1.runtime"]' >"$rootfs/tmp/preload.toml"
daemon_pid=; proc_mounted=; root_mounted=
stop_owned(){
 if test -n "$daemon_pid" && kill -0 "$daemon_pid" 2>/dev/null; then
  test "$(readlink -f "/proc/$daemon_pid/root")" = "$rootfs"
  tr '\0' '\n' <"/proc/$daemon_pid/cmdline" | grep -Fxq -- --address=/run/preload/containerd.sock
  kill -TERM "$daemon_pid"; wait "$daemon_pid" || true
 fi
}
cleanup(){ stop_owned; if test "$proc_mounted" = yes; then umount "$rootfs/proc"; fi; if test "$root_mounted" = yes; then umount "$rootfs"; fi; }
trap cleanup EXIT
mount --bind "$rootfs" "$rootfs"; root_mounted=yes
mkdir -p "$rootfs/proc"; ! mountpoint -q "$rootfs/proc"
mount -t proc -o ro,nosuid,nodev,noexec proc "$rootfs/proc"; proc_mounted=yes
chroot "$rootfs" /usr/bin/containerd --config=/tmp/preload.toml --root=/var/lib/containerd --state=/run/preload/state --address=/run/preload/containerd.sock >"$target/containerd-unpack.log" 2>&1 &
daemon_pid=$!
for iteration in $(seq 1 100); do
 test -S "$rootfs/run/preload/containerd.sock" && break
 kill -0 "$daemon_pid"; sleep .1
done
test -S "$rootfs/run/preload/containerd.sock"
for archive in "$build/shared-disk-v7/images/pods.tar.gz" "$rootfs/opt/kube-lab/images/upgrade-1.36.5.tar.gz"; do
 gzip -dc "$archive" | chroot "$rootfs" /usr/bin/ctr --address=/run/preload/containerd.sock -n k8s.io images import --local --snapshotter=overlayfs --platform=linux/386 -
done
chroot "$rootfs" /usr/bin/ctr --address=/run/preload/containerd.sock -n k8s.io images check --snapshotter=overlayfs >"$target/imagenes-desempaquetadas.txt"
cat "$target/imagenes-desempaquetadas.txt"
chroot "$rootfs" /usr/bin/ctr --address=/run/preload/containerd.sock -n k8s.io images check --snapshotter=overlayfs --quiet >"$target/imagenes-listas.txt"
for name in kube-apiserver kube-controller-manager kube-scheduler kube-proxy; do grep -Fxq "docker.io/s2ktux/$name:v1.36.5" "$target/imagenes-listas.txt"; done
# Verificar el fichero de la capa real sin utilizar la vista bind auxiliar
# de ctr (incompatible con esta combinación de CLI/mount-manager).
mapfile -d '' binaries < <(find "$rootfs/var/lib/containerd/io.containerd.snapshotter.v1.overlayfs/snapshots" -type f -path '*/fs/opt/kubernetes/bin/kube-browser-shared' -print0)
test "${#binaries[@]}" = 1
test "$(sha256sum "${binaries[0]}" | cut -d ' ' -f1)" = e4eba50402273fe2f8a4493eda499389116d678b961a123bed064babe99acf2a
stop_owned; daemon_pid=
umount "$rootfs/proc"; proc_mounted=
umount "$rootfs"; root_mounted=
test ! -e "$rootfs/etc/kubernetes/admin.conf"
test ! -e "$rootfs/var/lib/etcd/member"
chroot "$rootfs" dpkg-query -W kubeadm kubelet kubectl
# Solo retirar esta copia de un archivo ya conservado en admin-v1/v2 y en
# upgrade-images-v1. Sus blobs/snapshots reales permanecen en el runtime.
archive="$rootfs/opt/kube-lab/images/upgrade-1.36.5.tar.gz"
test "$(readlink -f "$archive")" = /home/s2ktux/kubernetes-browser-build-20261012/debian-admin-v3/rootfs/opt/kube-lab/images/upgrade-1.36.5.tar.gz
test "$(sha256sum "$archive" | cut -d ' ' -f1)" = 9c916e4113fa1a6dadc84903651da059c0ee956eec2f0f0c789259ee8713a7a8
rm -f -- "$archive"
test "$(du -sb "$rootfs" | cut -f1)" -lt 2900000000
raw="$target/kubernetes-debian-admin-v3.ext4"
test ! -e "$raw"; truncate -s 3G "$raw"
mkfs.ext4 -q -F -m 0 -L KUBE_ADMIN_V3 -d "$rootfs" "$raw"
sha256sum "$raw" >"$raw.sha256"
cat "$raw.sha256"
