import {cp,mkdir,stat} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
const origin=new URL('../../prototipo-linux-navegador/tools/v86-test/v86-1e4f43c95/',import.meta.url);
const destination=new URL('motor-experimento/fuentes-jit8192/',import.meta.url);
try{await stat(destination);throw Error('La copia experimental ya existe');}catch(error){if(error.code!=='ENOENT')throw error;}
await mkdir(destination,{recursive:true});
for(const path of ['src','lib','gen','tools/rust-lld-wrapper','.cargo','Cargo.toml','package.json','LICENSE'])await cp(new URL(path,origin),new URL(path,destination),{recursive:true,force:false,errorOnExist:true});
for(const name of ['jit','interpreter','analyzer']){
 const result=spawnSync(process.execPath,[fileURLToPath(new URL(`gen/generate_${name}.js`,destination)),'--all'],{cwd:fileURLToPath(destination),stdio:'inherit'});
 if(result.status!==0)throw Error('Falló el generador upstream '+name);
}
console.log('Copia privada y tablas upstream preparadas; todavía no se ha modificado ni compilado el motor.');
