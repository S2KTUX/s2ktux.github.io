#!/bin/bash
# Repositorios APT firmados propios con binarios reales, nunca alias de versión.
set -Eeuo pipefail
build=/home/s2ktux/kubernetes-browser-build-20261012
project=/mnt/d/RIVALIA/prototipo-contenedores-web/kubernetes-real
new="$build/upgrade-1.36.5-v2"
target="$build/upgrade-apt-v1"
test -f "$new/SHA256SUMS"
sha256sum -c "$new/SHA256SUMS"
test ! -e "$target"
mkdir -p "$target/key" "$target/stage"
chmod 700 "$target/key"
gpg --homedir "$target/key" --batch --pinentry-mode loopback --passphrase '' --quick-generate-key 'S2KTUX Kubernetes laboratory <lab@s2ktux.invalid>' ed25519 sign 0
gpg --homedir "$target/key" --export >"$target/s2ktux-kubernetes-lab.gpg"
for version in 1.35.9 1.36.5; do
 minor="${version%.*}"
 repo="$target/repo/v$minor"
 mkdir -p "$repo/pool" "$repo/dists/stable/main/binary-i386"
 for package in kubeadm kubelet kubectl; do
  stage="$target/stage/$package-$version"
  mkdir -p "$stage/DEBIAN" "$stage/usr/bin" "$stage/usr/share/doc/$package"
  if test "$version" = 1.36.5; then binary="$new/$package"
  else
   case "$package" in
    kubeadm) binary="$build/bin/kubeadm";;
    kubelet) binary="$build/bin/kube-browser-ecdsa-v3";;
    kubectl) binary="$project/fixture/root/bin/kubectl";;
   esac
  fi
  install -m 755 "$binary" "$stage/usr/bin/$package"
  if test "$package" = kubelet; then
   mkdir -p "$stage/lib/systemd/system/kubelet.service.d"
   install -m 644 "$project/debian/config/kubelet.service" "$stage/lib/systemd/system/kubelet.service"
   install -m 644 "$project/debian/config/10-kubeadm.conf" "$stage/lib/systemd/system/kubelet.service.d/10-kubeadm.conf"
  fi
  install -m 644 "$build/kubernetes-$version/LICENSE" "$stage/usr/share/doc/$package/copyright"
  printf 'Package: %s\nVersion: %s-0.s2ktux1\nArchitecture: i386\nMaintainer: S2KTUX laboratorio <lab@s2ktux.invalid>\nSection: admin\nPriority: optional\nDescription: Kubernetes %s - compilacion propia linux/386 de laboratorio\n Comandos upstream reales. No es un paquete oficial de Kubernetes.\n' "$package" "$version" "$package" >"$stage/DEBIAN/control"
  dpkg-deb --root-owner-group -Zgzip -z1 --build "$stage" "$repo/pool/${package}_${version}-0.s2ktux1_i386.deb"
 done
 (cd "$repo"; dpkg-scanpackages pool /dev/null >dists/stable/main/binary-i386/Packages)
 gzip -n -c "$repo/dists/stable/main/binary-i386/Packages" >"$repo/dists/stable/main/binary-i386/Packages.gz"
 (
  cd "$repo/dists/stable"
  # Fecha de medios offline compatible con el reloj de la base de prácticas.
  printf 'Origin: S2KTUX-Laboratorio\nLabel: Kubernetes compilacion propia\nSuite: stable\nCodename: stable\nDate: Mon, 12 Oct 2026 00:00:00 +0000\nArchitectures: i386\nComponents: main\nSHA256:\n'
  for file in main/binary-i386/Packages main/binary-i386/Packages.gz; do
   printf ' %s %s %s\n' "$(sha256sum "$file" | cut -d ' ' -f1)" "$(stat -c %s "$file")" "$file"
  done
 ) >"$repo/dists/stable/Release"
 gpg --homedir "$target/key" --batch --yes --digest-algo SHA256 --clearsign -o "$repo/dists/stable/InRelease" "$repo/dists/stable/Release"
 gpgv --keyring "$target/s2ktux-kubernetes-lab.gpg" "$repo/dists/stable/InRelease"
done
printf 'Paquetes y repositorios firmados preparados: %s\n' "$target"
