# Archivos del laboratorio Kubernetes

Estos archivos adaptan los complementos a las máquinas del navegador. Son procesos reales compilados para linux/386; no son imágenes oficiales para esa arquitectura. La base del curso sigue siendo Kubernetes 1.35.

Los manifiestos de tus aplicaciones se escriben normalmente con kubectl y tu editor. Aquí solo están los complementos que necesitan una preparación específica del navegador. HA y el upgrade completo siguen pendientes; esta carpeta no acredita todo el curso.

## Imágenes de complementos

En cada worker que vaya a ejecutar Traefik o Metrics Server, importa primero las imágenes preparadas. No hace falta para los ejemplos que solo usan busybox:1.37.0-musl.

    gzip -dc /mnt/kube-client/images/curso.tar.gz | ctr -n k8s.io images import --no-unpack --platform=linux/386 -

## Clases 15 y 23

Desde cka-cp1, instala los CRDs y comprueba que están establecidos. El paquete lab1 conserva las plantillas y valores del chart 37.1.1, pero los CRDs se gestionan aparte. El original se conserva para consultarlo.

    kubectl apply --server-side --field-manager=curso-crds --request-timeout=120s -f /opt/curso/15-23/crds/
    kubectl wait --for=condition=Established --timeout=120s -f /opt/curso/15-23/crds/
    helm upgrade --install traefik /opt/curso/15-23/traefik-37.1.1-lab1.tgz -n traefik --create-namespace --skip-crds -f /opt/curso/15-23/values.yaml

Para Gateway, conserva los valores anteriores y activa su proveedor:

    helm upgrade traefik /opt/curso/15-23/traefik-37.1.1-lab1.tgz -n traefik --reuse-values -f /opt/curso/15-23/gateway-values.yaml

Los listeners siguen usando 8000 y 8443. Los NodePort son 30080 y 30443.

## Clase 29

Usa la configuración de tres nodos. El manifiesto coloca Metrics Server en cka-w2 y acepta los certificados autofirmados de kubelet solo para este laboratorio.

    kubectl apply -f /opt/curso/29/metrics-server.yaml
    kubectl top nodes

## Clase 30

El chart web usa un servidor HTTP pequeño real de BusyBox para practicar Helm. No depende de ejecutar la imagen de nginx del guion. Puedes copiarlo antes de modificar sus archivos.

    helm template web /opt/curso/30/web-chart
    helm upgrade --install web /opt/curso/30/web-chart -n helm-lab --create-namespace --set replicaCount=2

## Clase 31

El Operator entregado gestiona una aplicación HTTP WebApp, no una base de datos. No tienes que programarlo. Su cuenta no tiene permisos de administrador.

    kubectl apply -f /opt/curso/31/operator.yaml
    kubectl apply -f /opt/curso/31/webapp.yaml
    kubectl get webapps,deployments -n curso-operator

Modificar spec.replicas en el WebApp debe cambiar el Deployment. Crear un CRD sin un controlador no desplegaría por sí solo ninguna aplicación.
